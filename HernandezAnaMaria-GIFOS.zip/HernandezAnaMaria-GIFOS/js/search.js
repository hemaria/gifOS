//Creacion caja busqqueda
const searchBox = (url, imgLink, title) => {
  const div = document.createElement("div");
  div.innerHTML = `<div class="gridCont">
      <a href="${url}" target="_blank">
        <img src="${imgLink}" alt="" class="tendgif portrait"/>
        <div class="background-tittle p-left-right tendtitle">
            <p class="text-color-white" id="gifHashtag">${title}</p>
        </div>                                
      </a>
  </div> `;

  return div.firstChild;
};

const searchTitle = (title) => {
  const div = document.createElement("div");
  div.innerHTML = `<p class="text-color-blue p-left" id="searchName">${title} (Resultados)</p>`;

  return div.firstChild;
};

// TERMINOS SUGERIDOS
const searchSuggestion = (sugerencia) => {
  const div = document.createElement("div");
  div.innerHTML = `<a>${sugerencia}</a>`;

  return div.firstChild;
};

//HASHTAGS SUGERIDOS
const suggestHashtagsbox = (hashtag) => {
  const div = document.createElement("div");
  div.innerHTML = `<button class="hashtagbtn text-color-white" id="hashtag">${hashtag}</button>`;
  return div.firstChild;
};

function loadSearchtitle() {
  const search = document.getElementById("inputBusqueda").value;
  const searchboxtext = document.getElementById("searchtitle");
  searchboxtext.innerHTML = "";
  searchboxtext.appendChild(searchTitle(search));
}

//BUSQUEDA
const searchFromInput = () => {
  opcionesBusqueda.innerHTML = "";
  executeSearch();
  getSearchResults();
  getHashtags();
  loadSearchtitle();
};

const executeSearch = () => {
  const sugeridos = document.getElementById("gifSugeridos");
  const trending = document.getElementById("trendingGif");
  const sugestSection = document.getElementById("sugestionSection");
  const trendSection = document.getElementById("trendSection");
  const searchSection = document.getElementById("searchSection");
  const searchHashtags = document.getElementById("hashtags");

  sugeridos.classList.add("displayno");
  trending.classList.add("displayno");
  sugestSection.classList.add("displayno");
  trendSection.classList.add("displayno");
  searchSection.classList.remove("displayno");
  searchHashtags.classList.remove("displayno");
};

function getSearchResults() {
  const search = document.getElementById("inputBusqueda").value.toLowerCase();
  fetch(`https://api.giphy.com/v1/gifs/search?api_key=${APIKEY}&q=${search}`)
    .then((response) => response.json())
    .then(({ data }) => {
      const container = document.getElementById("searchGif");
      container.innerHTML = "";

      for (i = 0; i < data.length; i++) {
        container.appendChild(
          searchBox(data[i].url, data[i].images.preview_gif.url, data[i].title)
        );
      }
    });
}

// HASHTAGS SUGERIDOS
function getHashtags() {
  const search = document.getElementById("inputBusqueda").value.toLowerCase();

  let i;
  const container = document.getElementById("hashtags");
  container.innerHTML = "";
  fetch(`https://api.giphy.com/v1/tags/related/${search}?api_key=${APIKEY}`)
    .then((response) => response.json())
    .then(({ data }) => {
      for (i = 0; i < 3; i++) {
        container.appendChild(suggestHashtagsbox(data[i].name));
      }
    });
}
