const sugeridosBox = (imgLink, sugeridosTitle) => {
  const div = document.createElement("div");
  div.innerHTML = `<div class=sugerido-box-gif>
    <div class="d-flex s-btw titlegif p-left-right">
      <p class="text-color-white" id="gifTitle">${sugeridosTitle}</p>
      <img id="close" src="./images/close.svg" alt="cerrar"/>
    </div>
    <button class="vermasbtn text-color-white">Ver más...</button>
    <img src="${imgLink}" alt="" class="imagengif"/>
  </div>`;

  return div.firstChild;
};

const trendBox = (url, imgLink, title) => {
  const div = document.createElement("div");
  div.innerHTML = `<div class="gridCont">
    <a href="${url}" target="_blank">
      <img src="${imgLink}" alt="" class="tendgif portrait"/>
      <div class="background-tittle p-left-right tendtitle">
          <p class="text-color-white" id="gifHashtag">${title}</p>
      </div>                                
    </a>
</div> `;

  return div.firstChild;
};

// CARGAR DEFAULT
window.onload = function () {
  loadSuggestions();
  loadTrends();
};

function loadSuggestions() {
  let i;
  const container = document.getElementById("gifSugeridos");

  for (i = 0; i < 4; i++) {
    fetch(`https://api.giphy.com/v1/gifs/random?api_key=${APIKEY}`)
      .then((response) => response.json())
      .then(({ data }) => {
        container.appendChild(sugeridosBox(data.image_url, data.title));
      });
  }
}

const loadTrends = () => {
  let i;
  const container = document.getElementById("trendingGif");

  fetch(`https://api.giphy.com/v1/gifs/trending?api_key=${APIKEY}&limit=12`)
    .then((response) => response.json())
    .then(({ data }) => {
      for (i = 0; i < data.length; i++) {
        container.appendChild(
          trendBox(data[i].url, data[i].images.preview_gif.url, data[i].title)
        );
      }
    });
};

// BUSQUEDA TENDENCIAS

//1. Boton
const inputBusqueda = document.getElementById("inputBusqueda");
const searchButton = document.getElementById("btnBuscar");
const opcionesBusqueda = document.getElementById("opcionesBusqueda");

let interval = null;
inputBusqueda.addEventListener("keyup", (e) => {
  const value = e.target.value;

  if (value.trim().length > 0) {
    searchButton.removeAttribute("disabled");
    autocomplete(value);
  } else {
    searchButton.setAttribute("disabled", "");
    const container = document.getElementById("opcionesBusqueda");
    container.innerHTML = "";
  }
});

//2. Autocomplete
function autocomplete(value) {
  fetch(
    `https://api.giphy.com/v1/gifs/search?api_key=${APIKEY}&limit=4&q=${value}`
  )
    .then((response) => response.json())
    .then(({ data }) => {
      const container = document.getElementById("opcionesBusqueda");
      container.innerHTML = "";

      for (i = 0; i <= 3; i++) {
        container.appendChild(searchSuggestion(data[i].title));
      }
    });
}

opcionesBusqueda.addEventListener("click", (e) => {
  const value = e.target.text;
  inputBusqueda.value = value;
  searchButton.click();
  opcionesBusqueda.innerHTML = "";
});
