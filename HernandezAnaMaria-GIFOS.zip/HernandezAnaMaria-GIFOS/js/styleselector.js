// DESPLEGAR ELECCION TEMA
function desplegableFuncion() {
  document.getElementById("dropdowntema").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function (event) {
  if (!event.target.matches(".dropbtn")) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains("show")) {
        openDropdown.classList.remove("show");
      }
    }
  }
};

// CAMBIO DE TEMA
// Cambio de tema 'onclick'
function estiloDark() {
  document.getElementById("styles").href = "./Styles/stylesdark.css";
  //document.getElementById("desplegableTema").style.display = "none";
  sessionStorage.setItem("tema", "dark");
  document.getElementById("logoimg").src = "./images/gifOF_logo_dark.png";
  sessionStorage.setItem("logodark");
}
function estiloLight() {
  document.getElementById("styles").href = "./Styles/stylescolor.css";
  //document.getElementById("desplegableTema").style.display = "none";
  sessionStorage.setItem("tema", "light");
  document.getElementById("logoimg").src = "./images/gifOF_logo.png";
  sessionStorage.setItem("logolight");
}

const tema = sessionStorage.getItem("tema");
if (tema == "light") {
  estiloLight();
} else if (tema == "dark") {
  estiloDark();
}
