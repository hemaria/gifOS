const mygifBox = (url, imgLink, title) => {
  const div = document.createElement("div");
  div.innerHTML = `<div class="gridCont">
    <a href="${url}" target="_blank">
      <img src="${imgLink}" alt="" class="tendgif portrait"/>
      <div class="background-tittle p-left-right tendtitle">
          <p class="text-color-white" id="gifHashtag">${title}</p>
      </div>                                
    </a>
</div> `;

  return div.firstChild;
};

window.onload = function () {
  loadMyGifos();
};

function loadMyGifos() {
  let i;
  const container = document.getElementById("misGifos");
  var gifos = localStorage.getItem("gifos");
  if (gifos) {
    var items = JSON.parse(gifos);
    console.log("gifos", items);
    for (i = 0; i < items.length; i++) {
      fetch(`https://api.giphy.com/v1/gifs/${items[i]}?api_key=${APIKEY}`)
        .then((response) => response.json())
        .then(({ data }) => {
          container.appendChild(
            mygifBox(data.url, data.images.original.url, data.id)
          );
        });
    }
  }
}
