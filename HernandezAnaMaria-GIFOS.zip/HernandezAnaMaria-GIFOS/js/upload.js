const misGuifos = document.getElementById("migifsection");
var stream = null;
var recorder = null;

// CLIC to start preview video
const gotoToolbarUno = () => {
  const toolbarUno = document.getElementById("toolbar1");
  toolbarUno.classList.remove("displayno");

  const toolbarTres = document.getElementById("toolbar3");
  toolbarTres.classList.add("displayno");

  const preview = document.getElementById("preview");
  preview.classList.add("displayno");

  const video = document.getElementById("video");
  video.classList.remove("displayno");
};

const gotoWindowDos = () => {
  const windowUno = document.getElementById("windowUno");
  windowUno.classList.remove("show");
  windowUno.classList.add("displayno");

  const windowDos = document.getElementById("windowDos");
  windowDos.classList.remove("displayno");
  misGuifos.classList.add("displayno");

  getStreamAndRecord();
};

const gotoToolbarDos = () => {
  const toolbarUno = document.getElementById("toolbar1");
  toolbarUno.classList.add("displayno");

  const toolbarDos = document.getElementById("toolbar2");
  toolbarDos.classList.remove("displayno");

  const toolbarTres = document.getElementById("toolbar3");
  toolbarTres.classList.add("displayno");

  const preview = document.getElementById("preview");
  preview.classList.add("displayno");

  const video = document.getElementById("video");
  video.classList.remove("displayno");

  startCapture();
};

const gotoToolbarTres = () => {
  const toolbarDos = document.getElementById("toolbar2");
  toolbarDos.classList.add("displayno");

  const toolbarTres = document.getElementById("toolbar3");
  toolbarTres.classList.remove("displayno");

  stopCapture();
};

const gotoWindowCuatro = () => {
  const windowCuatro = document.getElementById("window4");
  windowCuatro.classList.remove("displayno");

  const windowDos = document.getElementById("windowDos");
  windowDos.classList.add("displayno");

  uploadCapture();
};

const gotoWindowCinco = (gifId) => {
  const windowCinco = document.getElementById("finalLoad");
  windowCinco.classList.remove("displayno");

  const windowCuatro = document.getElementById("window4");
  windowCuatro.classList.add("displayno");
  misGuifos.classList.remove("displayno");
  misGuifos.classList.add("show");

  /*recorder.camera.stop();
  recorder.destroy();
  recorder = null;*/

  getMyGifo(gifId);
};

function StopFunction() {
  window;
}

function getStreamAndRecord() {
  navigator.mediaDevices
    .getUserMedia({
      audio: false,
      video: {
        height: { max: 320 },
        width: { max: 660 },
      },
    })
    .then(function (strm) {
      stream = strm;
      video.srcObject = strm;
      video.play();
    });
}

function startCapture() {
  recorder = RecordRTC(stream, {
    type: "gif",
    frameRate: 1,
    quality: 10,
    width: 660,
    height: 320,
    canvas: {
      width: 660,
      height: 320,
    },
    onGifRecordingStarted: function () {
      console.log("started");
    },
  });

  recorder.startRecording();
}

function stopCapture() {
  recorder.stopRecording((e) => {
    const preview = document.getElementById("preview");
    preview.src = URL.createObjectURL(recorder.getBlob());
    preview.classList.remove("displayno");

    const video = document.getElementById("video");
    video.classList.add("displayno");
  });
}

function uploadCapture() {
  const upload = new FormData();
  upload.append("file", recorder.getBlob(), "myGif.gif");
  console.log(upload.get("file"));

  fetch("https://upload.giphy.com/v1/gifs?&api_key=" + APIKEY, {
    method: "POST",
    body: upload,
  })
    .then((res) => {
      console.log(res.status);
      return res.json();
    })
    .then((data) => {
      const gifId = data.data.id;
      console.log("id del gif: ", gifId);

      var gifos = localStorage.getItem("gifos");
      var items = [];
      if (gifos) {
        items = JSON.parse(gifos);
      }

      items.unshift(gifId);

      localStorage.setItem("gifos", JSON.stringify(items));

      gotoWindowCinco(gifId);
    })
    .catch((error) => {
      console.error("Error al subir el Gif:", error);
    });
}

const getMyGifo = (gifId) => {
  fetch(`https://api.giphy.com/v1/gifs/${gifId}?api_key=${APIKEY}`)
    .then((response) => response.json())
    .then(({ data }) => {
      const previewFinal = document.getElementById("previewFinalload");
      previewFinal.src = data.images.original.url;

      const copyUrl = document.getElementById("copygifUrl");
      const linkUrl = document.getElementById("opengifUrl");

      copyUrl.href = data.url;
      linkUrl.href = data.url;
    });
};
