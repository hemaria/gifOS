const APIKEY = "MzVQbYV1E2nolhHyjgJGznLt519WRgxJ";


// CARGAR SUGERENCIAS

/*
window.onload = function() {
  loadSuggestions();
};


function loadSuggestions(){
 var i;
  for (i = 0; i < 4; i++) { 
    fetch(`https://api.giphy.com/v1/gifs/random?api_key=${APIKEY}`)
  .then(response => response.json())
  .then(({data}) => {
    console.log(data);
    const container= document.getElementById('gifSugeridos');
    div = document.createElement("div");
    var img = document.createElement("img");
    img.alt= data.title;
    img.src = data.image_url;
		var link = document.createElement("a");
		link.href = data.url;
		link.appendChild(document.createTextNode("Ver más..."));
    div.appendChild(link);
    div.appendChild(img);
    container.appendChild(div);
  });
}
}
*/


// DESPLEGAR ELECCION TEMA
function desplegableFuncion() {
    document.getElementById("dropdowntema").classList.toggle("show");
  }
  
  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }

  // CAMBIO DE TEMA

  // Cambio de tema 'onclick'
function estiloDark(){
    document.getElementById('styles').href = './Styles/stylesdark.css';
    document.getElementById('desplegableTema').style.display = 'none';
    sessionStorage.setItem("tema", "dark")
    document.getElementById('logoimg').src = './images/gifOF_logo_dark.png';
  }
  function estiloLight(){
    document.getElementById('styles').href = './Styles/stylescolor.css';
    document.getElementById('desplegableTema').style.display = 'none';
    sessionStorage.setItem("tema", "light")
    document.getElementById('logoimg').src = './images/gifOF_logo.png';
  }
  

  // BUSQUEDA TENDENCIAS

  //1. Boton

  function eventosBuscador(){
    // Inicializa los escuchadores de eventos del buscador
    // Cuando el usuario introduzca texto en la caja, habilitar el boton
    const inputBusqueda = document.querySelector("#inputBusqueda");
    inputBusqueda.addEventListener("input", function(evento){
        // habililitar el boton
        const buttonBusqueda = document.querySelector("#buttonBusqueda");

        if(evento.target.value ==="") {
            // si la caja de texto esta vacia, deshabilitar el boton
            buttonBusqueda.setAttribute("disabled", true);
        } else {
            // si no habilitarlo
            buttonBusqueda.removeAttribute("disabled");
        }       
    })
  }